'use client'

import { createContext, useState } from 'react'
export const taskContext = createContext({})

export default function TaskContextProvider({ children }) {
  const savedTasks = localStorage.getItem('all-tasks')
  const ParseSavedData = JSON.parse(savedTasks)
  const [allTask, setAllTask] = useState(ParseSavedData ? ParseSavedData : [])
  const [name, setName] = useState('')
  const [description, setDescription] = useState('')
  const [edit, setEdit] = useState(false)

  return (
    <taskContext.Provider
      value={{
        allTask,
        setAllTask,
        name,
        setName,
        description,
        setDescription,
        edit,
        setEdit,
      }}
    >
      {children}
    </taskContext.Provider>
  )
}
