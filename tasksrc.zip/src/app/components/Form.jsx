import React, { useContext, useEffect, useState } from 'react'
import { taskContext } from '../Context'
import { useParams, useRouter } from 'next/navigation'
import toast from 'react-hot-toast'

const Form = ({ name, setName, description, setDescription }) => {
  const router = useRouter()
  const { id } = useParams()
  const { edit, setEdit, allTask, setAllTask } = useContext(taskContext)
  const [isValidate, setIsValidate] = useState(true)
  // random id generation
  const randomId = () => {
    let id = Math.random()
    return id
  }
  // handle create btn
  const handleSubmitBtn = (e) => {
    e.preventDefault()
    try {
      let id = randomId()
      let newTask = [...allTask, { name, description, id, isDone: false }]
      setAllTask(newTask)
      toast.success('Task added')
      router.push('/')
    } catch (error) {
      console.log(error)
    } finally {
      setName('')
      setDescription('')
    }
  }

  // handle save btn
  const handleSaveBtn = (e) => {
    e.preventDefault()
    try {
      const updatedTask = allTask.map((task) => {
        if (task.id == id) {
          return {
            ...task,
            name: name,
            description: description,
            isDone: false,
          }
        }
        return task
      })
      setAllTask(updatedTask)
      setEdit(false)
      toast.success('Task updated successfully')
      router.push('/')
    } catch (error) {
      console.log(error)
    } finally {
      setName('')
      setDescription('')
    }
  }

  useEffect(() => {
    if (name.trim('').length > 0 && description.trim('').length > 0) {
      setIsValidate(false)
    } else {
      setIsValidate(true)
    }
  }, [name, description])
  return (
    <form className="w-full md:w-1/2 flex flex-col gap-2">
      <div className="flex flex-col">
        <label className="font-sans" htmlFor="name">
          Name
        </label>
        <input
          className="outline-none  text-black pl-2 p-1 rounded-sm"
          type="text"
          id="name"
          value={name}
          onChange={(e) => {
            setName(e.target.value)
          }}
          required
        />
        <small className="mt-1 text-red-500 font-sans">
          {isValidate && 'Name should not be empty.'}
        </small>
      </div>
      <div className="flex flex-col ">
        <label className="font-sans" htmlFor="desc">
          Description
        </label>
        <textarea
          className="outline-none resize-none text-black pl-2 p-1 rounded-sm"
          id="desc"
          cols={10}
          rows={4}
          value={description}
          onChange={(e) => {
            setDescription(e.target.value)
          }}
          required
        ></textarea>
        <small className="mt-1 text-red-500 font-sans">
          {isValidate && 'Description should not be empty.'}
        </small>
      </div>

      <button
        onClick={edit ? handleSaveBtn : handleSubmitBtn}
        className="bg-green-700 duration-100 cursor-pointer transition-all hover:bg-green-800 uppercase font-sans w-fit px-4 py-2 self-center rounded-sm mt-2 font-semibold"
        disabled={isValidate}
      >
        {edit ? 'Save' : 'Submit'}
      </button>
    </form>
  )
}

export default Form
